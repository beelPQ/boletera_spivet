<?php
defined('_JEXEC') or die;
 
class mod_my_shoppingHelper{
 public static function getMCL(&$params){
	 $CodigoCL = "";
   return $CodigoCL;  
 }
}
?>