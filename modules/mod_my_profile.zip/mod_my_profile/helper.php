<?php
defined('_JEXEC') or die;
 
class mod_my_profileHelper{
 public static function getMCL(&$params){
	 $CodigoCL = "";
   return $CodigoCL;  
 }
}
?>